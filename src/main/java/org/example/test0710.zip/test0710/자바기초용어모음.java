package org.example.test0710;

import org.example.chapter05.F_Overloading;

public class 자바기초용어모음 {
}

/*
접근제한자
: ...

- public: 차이를
- protected: 사실
- default: 잘
- private: 모르겠습니다...

Static
: 공통적... 으로 사용함

- static 변수: 클래스에 소속되지 않고 사용할 수 있는 변수
- static 메서드: 모든 클래스가 공통적으로 실행하는 메서드

final
: 최종... 마지막?

- final 변수: ...
- final 메서드: 상속되지 않고 고정되는 메서드
- final 클래스: 상속되지 않고 고정되는 클래스

- this: 객체를 만들 때 사용...?
- super: ... 오버라이딩 할 때 사용한 것 같음

- overloading: 동일한 이름의 매개변수를 다르게 사용
- overriding: 부모의 메서드를 다르게 사용

abstract
: ... 추상적인?

- abstract 클래스: 추상 메서드를 1개 이상 사용해야 함, 일반 메서드도 사용 가능 
- abstract 메서드: 메서드의 선언부만 작성한 다음 상속하여 구현부를 작성함

- interface: ...
- abstract class: ...
- 차이점을 써야 되는데 모르겠습니다

- extends: 부모 클래스/인터페이스의 속성을 자식 클래스/인터페이스에 상속함
- implements: 부모 클래스의 속성을 자식 인터페이스에 상속함

- try: 발생할 수 있는 오류 코드를 입력
- catch: 오류 코드 발생 시 출력될 코드를 입력
- finally: 오류 코드가 발생하지 않았을 때 출력될 코드를 입력

 */

