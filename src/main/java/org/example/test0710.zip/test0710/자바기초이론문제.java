package org.example.test0710;

public class 자바기초이론문제 {
}
/*

Q1. D

Q2. B

Q3. A

Q4. B

Q5. C

Q6. B

Q7. C

Q8. A

Q9. D

Q10. D

Q11.

Q12. String name 값이 없어서

 */
