package org.example.test0710.자바OOP구현문제;

public class Q4 {
}
